const time2 = new Date().getTime();
                nvEl = {
                  time: time2,
                  page: window.location.pathname
                };
                let navigation = JSON.parse(localStorage.getItem("navigation"));
                navigation.push(nvEl);
                localStorage.setItem("navigation", JSON.stringify(navigation));