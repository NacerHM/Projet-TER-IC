var checkLinksInterval = setInterval(function() {
    var links = document.querySelectorAll('a[target="_blank"]');
    if (links.length > 0) {
      console.log('Lien avec target="_blank" trouvé.');
      links[0].removeAttribute('target');
      clearInterval(checkLinksInterval);
    }
  }, 2000);

  if (localStorage.getItem("cle") === "code de session"){
      const time = new Date().getTime();
      nvEl = {
          time: time,
          page: window.location.pathname
      };
      let navigation = JSON.parse(localStorage.getItem("navigation"));
      navigation.push(nvEl);
      localStorage.setItem("navigation", JSON.stringify(navigation));
  } else {
      window.location.href = "https://test-uga.fr/vch/transition/transition1.html";
  }