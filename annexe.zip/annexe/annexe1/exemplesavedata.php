<?php
    $json = file_get_contents('php://input');
    $data = json_decode($json);

    if ($data === null && json_last_error() !== JSON_ERROR_NONE) {
        exit();
    }
    $filename = uniqid() . '.json';
    file_put_contents('data/exemple' . $filename, $json); // a modifier avec le nom de la sessions exemple : file_put_contents('data/session' . $filename, $json);
?>